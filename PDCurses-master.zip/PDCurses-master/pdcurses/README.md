PDCurses Portable Core
======================

This directory contains core PDCurses source code files common to all
platforms.


Building
--------

These modules are built by the platform-specific makefiles, in the
platform directories.


Acknowledgements
----------------

The panel library was originally provided by
Warren Tucker <wht@n4hgf.mt-park.ga.us>
